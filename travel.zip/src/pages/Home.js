import "../styles/home.css";
import Body from "./Body";
// import Footer from "../components/Footer"

const Home = () => {
  return (
    <div className="home">
      <Body />
      {/* <Footer/> */}
    </div>
  );
};
export default Home;
